#include<stdio.h>
int main()
{
    int a=4;
    printf("%d\n",a--);
     printf("%d",--a);
}

