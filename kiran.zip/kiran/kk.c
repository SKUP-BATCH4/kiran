#include<stdio.h>
int main()
{
int a,b;
printf("enter the value of a:\n");
printf("enter the value of b:\n");
scanf("%d\n%d\n%d",&a,&b);
printf("%d%d",a,b);
}
