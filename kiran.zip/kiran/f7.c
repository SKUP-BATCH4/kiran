#include<stdio.h>
#include"copy one text to another.c"
extern int display();
int x=10;
void main()
{
    display();
}
